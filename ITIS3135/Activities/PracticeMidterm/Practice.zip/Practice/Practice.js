var $ = function(id) {
	return document.getElementById(id);
};

window.onload = function() {


	//add onclick event handler for each image

	// for click event add item to order and update total

	// display order and total

	
		
}; // end onload